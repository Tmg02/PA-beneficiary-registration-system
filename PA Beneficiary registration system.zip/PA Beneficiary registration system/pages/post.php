<?php
$host = "localhost";
$user = "root";
$pass = "";
$db = "PublicAssistance";

$con = mysqli_connect($host,$user,$pass,$db);
if (!$con){ 
	echo "There is a problem connecting the database"; 
}
if (isset($_POST['save'])) {
$name = $_POST['name'];
$surname =$_POST['surname'];
$dob = $_POST['dob'];
$phoneNumber = $_POST['phoneNumber'];
$category = $_POST['category'];
$address = $_POST['address'];
$gender = $_POST['gender'];
	 $nId = mysqli_real_escape_string($con, $_POST['nId']);
	 $check_duplicate_nId = "SELECT nId FROM Benefiary WHERE nId = '$nId'";
	 $result = mysqli_query($con, $check_duplicate_nId);
	 $count = mysqli_num_rows($result);
	 if ($count > 0) {
		 echo "<script> alert('Beneficiary already exists')</script>";
		 header('location:index.php');
		 return false;}
 }
$qry = ("INSERT INTO `benefiary`(`nId`, `phoneNumber`, `name`, `surname`, `dob`, `address`, `category`, `gender`) VALUES ('$nId','$phoneNumber','$name','$surname','$dob','$address','$category','$gender')");
$insert = mysqli_query($con, $qry);
if (!$insert){
	echo "There were problems while saving data";
}
else{
	//echo '<script>alert("Data saved")</script>';
	header('location:test.php');
}
?> 
<script>
function postSucceed(){
	alert("Data saved")
 
}

</script>