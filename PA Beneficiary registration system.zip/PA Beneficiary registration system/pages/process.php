<?php

$mysqli = new mysqli('localhost', 'root', '', 'PublicAssistance') or die(mysqli_error($mysqli));
    $id = $_GET['deleteid'];
    mysqli_query($mysqli, "delete from benefiary where id=$id");?>

    <script type="text/javascript">
        window.location="test.php";
    </script>
?>
