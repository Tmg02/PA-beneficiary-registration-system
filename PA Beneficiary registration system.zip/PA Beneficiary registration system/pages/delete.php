<?php 
session_start();

	include("connection.php");
	include("functions.php");
 $id = $_GET['deleteid'];
 $sql = "SELECT * FROM benefiary Where id =$id";
 $result =mysqli_query($con, $sql);
 $row = mysqli_fetch_assoc($result);
 $name = $row['name'];
 $surname=$row['surname'];
 $dob=$row['dob'];
 $phoneNumber= $row['phoneNumber'];
 $category=$row['category'];
 $address=$row['address'];
 $gender=$row['gender'];
 $nId=$row['nId'];
 if(isset($_POST['save']))
 {
	 $name = $_POST['name'];
	 $surname =$_POST['surname'];
	 $dob = $_POST['dob'];
	 $phoneNumber = $_POST['phoneNumber'];
	 $category = $_POST['category'];
	 $address = $_POST['address'];
	 $gender = $_POST['gender'];
	 $nId = $_POST['nId'];
     $user =$_POST['user'];
     $reason =$_POST['reason'];
	 $query = ("INSERT INTO `ben_deleted`(`nId`, `phoneNumber`, `name`, `surname`, `dob`, `address`, `category`, `gender`, `user`, `reason`) VALUES ('$nId','$phoneNumber','$name','$surname','$dob','$address','$category','$gender','$user','$reason')");
	 $query_run = mysqli_query($con, $query);
     
 
	 if($query_run)
	 {
		 $_SESSION['status'] = "Data Updated Successfully";
         mysqli_query($con, "delete from benefiary where id=$id");
		 header("Location: deleted_database.php");
	 }
	 else
	 {
		 $_SESSION['status'] = "Not Updated";
	 }
 }
?><!DOCTYPE html>
<html>
<head>
	<title>My website
	</title>
	<link rel="stylesheet" type="text/css" href="bootstrap.css">
<link rel="stylesheet" type="text/css" href="bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="bootstrap.rtl.css">
<link rel="stylesheet" type="text/css" href="bootstrap.rtl.min.css">
<link rel="stylesheet" type="text/css" href="bootstrap-grid.css">
<link rel="stylesheet" type="text/css" href="bootstrap-grid.min.css">
<link rel="stylesheet" type="text/css" href="bootstrap-grid.rtl.css">
<link rel="stylesheet" type="text/css" href="bootstrap-grid.rtl.min.css">
<link rel="stylesheet" type="text/css" href="bootstrap-reboot.css">
<link rel="stylesheet" type="text/css" href="bootstrap-reboot.min.css">
<link rel="stylesheet" type="text/css" href="bootstrap-reboot.rtl.css">
<link rel="stylesheet" type="text/css" href="bootstrap-reboot.rtl.min.css">
<link rel="stylesheet" type="text/css" href="bootstrap-utilities.css">
<link rel="stylesheet" type="text/css" href="bootstrap-utilities.min.css">
<link rel="stylesheet" type="text/css" href="bootstrap-utilities.rtl.css">
<link rel="stylesheet" type="text/css" href="bootstrap-utilities.rtl.min.css">
	<link rel="stylesheet" href="sites\css\font-awesome.min.css"> 
	
</head>
<body>
<body>
	<style type="text/css">

#text{

height: 17px;
padding: 4px;
width: 25%;
border-radius: 3px;
border-color: none;
}

#button{

padding: 10px;
margin-right: 5px;
width: 100px;
color: white;
border-radius: 7px;
transition: all 0.3s ease 0s;
cursor: pointer;
}
#box{
margin-left: 1060px;
align-content: flex-end;
margin-top: -170px;
}
.nav_links {
margin-top: 60px;
margin-left: 550px;
list-style: none;
}
.nav_links li {
display: inline-block;
}

.nav_links li a {
transition: all 0.3s ease 0s;
}

.nav_links li a:hover {
color: #0088a9;
}

.nav_links input{
width: 200px;
color: white;
transition: all 0.3s ease 0s;
border-radius: 7px;

}

</style>
<header style="margin-left: -25px;">

<ul style="list-style: none; margin-left: -10px;">

    <li style="margin-top: -10px;"><a href="Home.php"><img src="logo_MoPWLSW-2.png"></a></li>
	<li><div style="margin-top: -120px; margin-left: 160px;">
		<h3> Ministry of<br>Public Service, Labour<br>Social Welfare.<br>Department of Social Welfare</h3>
	</div></li>
	

	<div id="box">
		
		<form method="post">
<br>
			<a href="Home.php"><input id="button" type="button" class="btn btn-success" value="Log-Out"></a>
		</form>
	</div>
	<script>
function myFunction() {
  alert("Data Saved.");
} 
function myLogin(){
	alert("Welcome '<?php echo $user_data['user_name']; ?>'")
}
</script>
	<div class="nav_links">
		<nav>
		<lu>
			<li><a href="index.php"><input type="button" class="btn btn-success" name="" value="Beneficiary Registration" style="height: 40px; cursor:pointer;"></a></li>
			<li><a href="test.php"><input type="button" class="btn btn-success" name="" value="National Database" style="height: 40px; cursor:pointer;"></a></li>
			<li><a href="Contact.html"><input type="button" class="btn btn-success" name="" value="Contact Us" style="height: 40px; cursor:pointer;"></a></li>
			
		</lu>
		
	</div>
	</nav><br>
	<div><hr style="width: 75%; color: black; margin-left: 160px;"></div>
</ul>
	</header><br><h2 style="color: green; text-align:center;">Delete Beneficiary Data</h2><br>

	
	
	<form method="POST">
  <div class="form-row">
	  
<div class="form-check form-check-inline col-md-5">
&nbsp;&nbsp;&nbsp;<label class="form-check-label" for="name">Name:</label>
<input type="text"  class="form-control" id="name" name="name" value="<?php echo $row['name'];?>" readonly>
</div>
<div class="form-check form-check-inline col-md-5">
&nbsp;&nbsp;&nbsp;<label class="form-check-label text-left" for="surname">Surname:</label>
<input type="text"  class="form-control" id="surname" name="surname" value="<?php echo $row['surname'];?>" readonly>
</div><br><br><br>

<div class="form-check form-check-inline col-md-4">
&nbsp;&nbsp;&nbsp;<label class="form-check-label" for="Name">ID:</label>
<input type="text"  class="form-control" id="nId" name="nId" value="<?php echo $row['nId'];?>" readonly>
</div>
<div class="form-check form-check-inline col-md-3">
&nbsp;&nbsp;&nbsp;<label class="form-check-label" for="phoneNumber">Phone Number:</label>
<input type="number"  class="form-control" id="phoneNumber" name="phoneNumber" value="<?php echo $row['phoneNumber'];?>" readonly>
</div>
<div class="form-check form-check-inline col-md-3">
&nbsp;&nbsp;&nbsp;<label class="form-check-label" for="dob">Date of Birth:</label>
<input type="date"  class="form-control" id="dob" name="dob" value="<?php echo $row['dob'];?>" readonly>
</div><br><br><br>
<div class="form-check form-check-inline col-md-10">
&nbsp;&nbsp;&nbsp;<label class="form-check-label" for="address">Address:</label>
<input type="text"  class="form-control" id="address" name="address" value="<?php echo $row['address'];?>" readonly>
</div><br><br><br>
<div class="form-check form-check-inline col-md-4">
&nbsp;&nbsp;&nbsp;<label class="form-check-label text-left" for="category">Category:</label>
<select name="category" id="category" class="form-control" value="<?php echo $row['category'];?>" readonly >
			<option value="<?php echo $row['category'];?>">Elderly</option>
					<option value="Disabled">Disabled</option>
					<option value="SFT">SFT</option>
					<option value="Albinism">Albinism</option>
					<option value="Blind">Blind</option>
					<option value="Child-Headed">Child Headed</option>
					<option value="Chronic-Illiness">Chronic Illness</option>
				</select></div>
<div class="form-check form-check-inline col-md-1">
&nbsp;&nbsp;&nbsp;<label class="form-check-label text-left" for="gender">Gender:</label>
<input type="text" class="form-control" id="gender" name="gender" value="<?php echo $row['gender'];?>"  readonly></div><br><br>
<div class="form-check form-check-inline col-md-4">
&nbsp;&nbsp;&nbsp;<label class="form-check-label" for="reason">Reason:</label>
<textarea  class="form-control" name="reason" rows="2" required></textarea>
</div>
<div class="form-check form-check-inline col-md-3">
&nbsp;&nbsp;&nbsp;<label class="form-check-label" for="user">User:</label>
<input type="text"  class="form-control" name="user"  required>
</div>



    
  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<button type="submit" name="save" class="btn btn-success">Save</button><br><br>
</form>