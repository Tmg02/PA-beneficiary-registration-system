<?php
session_start();
include ("connection.php");

$id =$_GET['updateid'];
if(isset($_POST['save']))
{
    $name = $_POST['name'];
    $surname =$_POST['surname'];
    $dob = $_POST['dob'];
    $phoneNumber = $_POST['phoneNumber'];
    $category = $_POST['category'];
    $address = $_POST['address'];
    $gender = $_POST['gender'];
    $nId = $_POST['nId'];
    $query = "UPDATE benefiary SET id =$id,phoneNumber='$phoneNumber',name='$name',surname='$surname',dob='$dob',
    address='$address',category='$category',gender='$gender', nId='$nId' WHERE id=$id";
    $query_run = mysqli_query($con, $query);

    if($query_run)
    {
        $_SESSION['status'] = "Data Updated Successfully";
        //header("Location: index.php");
    }
    else
    {
        $_SESSION['status'] = "Not Updated";
    }
}

?>