<?php 
session_start();

	include("connection.php");
	include("functions.php");
	$user_data = check_login($con);
 $id = $_GET["id"];
$name="";
$surname="";
$nId="";
$phoneNumber="";
$dob="";
$gender="";
$category="";
$address="";

$res = mysqli_query($con, "SELECT * FROM benefiary WHERE id=$id");
while ($row= mysqli_fetch_array($res)) {
    $name =$row["name"];
    $surname =$row["surname"];
    $nId =$row["nId"];
    $phoneNumber =$row["phoneNumber"];
    $dob =$row["dob"];
    $gender =$row["gender"];
    $category =$row["category"];
    $address =$row["address"];
}
?><!DOCTYPE html>
<html>
<head>
	<title>MPSLSW
	</title>
	<link rel="stylesheet" href="sites\css\font-awesome.min.css"> 
	<style type="text/css">
		table{
			width: 100%;
			color: #228b22;
			font-family: monospace;
			font-size: 25px;
			text-align: center;
			border-collapse: separate;
		}
		th{
			background-color: #228b22;
			color: white;
			border-color: black;
		}
	</style>
</head>
<body>
<style type="text/css">

#text{

height: 17px;
padding: 4px;
width: 25%;
border-radius: 3px;
border-color: none;
}

#button{

padding: 10px;
margin-right: 5px;
width: 100px;
color: white;
border-color: #228b22;
background-color: #228b22;
border-radius: 7px;
transition: all 0.3s ease 0s;
cursor: pointer;
}
#button:hover{
background-color: black;
}

#box{
margin-left: 1060px;
align-content: flex-end;
margin-top: -170px;
}
.nav_links {
margin-top: 85px;
margin-left: 550px;
list-style: none;
}
.nav_links li {
display: inline-block;
}

.nav_links li a {
transition: all 0.3s ease 0s;
}

.nav_links li a:hover {
color: #0088a9;
}

.nav_links input{
width: 200px;
color: white;
background-color: #228b22;
transition: all 0.3s ease 0s;
border-radius: 7px;

}
.descrip {
color: #228b22;


}
.footer{
background-color: grey;
color: #fff;
}
.footer h3{
font-size: 15px;
margin: 25px 0;
}
.footer p{
font-size: 12px;
}
.col-md-3 .fa{
color: #fff;
}
a{
text-decoration: none;
}
.copyright{
margin-bottom: -80px;
text-align: center;
font-size: 15px;
padding-bottom: 20px;
}
.footer hr{
margin-top: 10px;
background-color: #ccc;  
}
.footer .row .fa{
padding-right: 20px;
font-size: 15px;
}
.row{
text-align: left;
}
.copyright .fa{
color: #fff;
}
.hr {
width: 50px;
align-items: center;
}
</style>
<header style="margin-left: -25px;">

<ul style="list-style: none; margin-left: -10px;">

    <li style="margin-top: -10px;"><a href="Home.php"><img src="logo_MoPWLSW-2.png"></a></li>
	<li><div style="margin-top: -120px; margin-left: 160px;">
		<h2> Ministry of<br>Public Service, Labour<br>Social Welfare.<br>Department of Social Welfare</h2>
	</div></li>
	

	<div id="box">
		<a href="Home.php"><input id="button" type="submit" value="Log-Out"></a>
	</div>
	<script>
function myFunction() {
  alert("Log in to gain access.");
}
function myLogin(){
	alert("Welcome '<?php echo $user_data['user_name']; ?>'")
}
</script>
	<div class="nav_links">
		<nav>
		<lu>
			<li><a href="index.php"><input type="button" name="" value="Beneficiary Registration" style="height: 40px; cursor:pointer;"></a></li>
			<li><a href=""><input type="button" name="" value="National Database" style="height: 40px;  cursor:pointer;"></a></li>
			<li><a href="#"><input type="button" name="" value="Contact Us" style="height: 40px;  cursor:pointer;"></a></li>
			
		</lu>
		
	</div>
	</nav><br>
	<div><hr style="width: 75%; color: black; margin-left: 160px;"></div>
</ul>
	</header><br><br>

	<div style="text-align: center; color: #228b22;"><h3>Beneficiary Deletion</h3></div>
	<form method="POST">
		<table>
			<tr>
				<td><h3>Name: </h3></td>
				<td><input type="text" id="name" name="name" placeholder="<?php echo $name; ?>"></td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
				<td></td><td><h3>Surname: </h3></td>
				<td><input type="text" id="surname" name="surname" placeholder="<?php echo $surname; ?>"></td>
				<td><h3>Phone Number: </h3></td>
				<td><input type="number" id="phoneNumber" name="phoneNumber" placeholder="<?php echo $phoneNumber; ?>"></td>
				
			</tr>
			<tr>
			<td><h3>ID: </h3></td>
				<td><input type="text" id="nId" name="nId" placeholder="<?php echo $nId; ?>"></td>
				<td></td><td><h3>D.O.B: </h3></td>
				<td><input type="date" name="dob" id="dob" placeholder="<?php echo $dob; ?>"></td>
				<td><h3>Gender: </h3></td>
				<td><input type="radio" id="gender" name="gender" placeholder="<?php echo $gender; ?>" ><label for="">Male</label>
				<input type="radio" id="gender" name="gender" placeholder="<?php echo $gender; ?>" ><label for="">Female</label></td>
			</tr>
			<tr>
			<td><h3>Category: </h3></td>
				<td>
				<select name="category" id="category" aria-placeholder="<?php echo $category; ?>" >
					<option value="Elderly">Elderly</option>
					<option value="Disabled">Disabled</option>
					<option value="SFT">SFT</option>
					<option value="Albinism">Albinism</option>
					<option value="Blind">Blind</option>
					<option value="Child-Headed">Child Headed</option>
					<option value="Chronic-Illiness">Chronic Illness</option>
				</select></td>
				<td></td><td><h3>Address: </h3></td>
				<td><input type="text" name="address" placeholder="<?php echo $address; ?>" ></td>
                <td><h3>Reason:</h3></td>
                <td><input type="text" name="reason" required></td>
			</tr>
			<tr></tr>
			<tr>
				<td><button type="submit" >Confirm <i class="fa fa-save"></button></td>
			</tr>
		</table>
	</form> 
	<?php
$host = "localhost";
$user = "root";
$pass = "";
$db = "PublicAssistance";

$con = mysqli_connect($host,$user,$pass,$db);
if (!$con){
	echo "There is a problem connecting the database"; 
}
$name = $_POST['name'];
$surname =$_POST['surname'];
$dob = $_POST['dob'];
$phoneNumber = $_POST['phoneNumber'];
$category = $_POST['category'];
$address = $_POST['address'];
$gender = $_POST['gender'];
$nId = $_POST['nId'];
$reason=$_POST['reason'];

$qry = ("INSERT INTO `ben_deleted`(`nId`, `phoneNumber`, `name`, `surname`, `dob`, `address`, `category`, `gender`, 'reason', 'user') VALUES ('$nId','$phoneNumber','$name','$surname','$dob','$address','$category','$gender', '$reason', '$user_data' )");
$insert = mysqli_query($con, $qry);

if (!$insert){
	echo "There were problems while saving data";
}
else{
	
}
?>