<?php 
session_start();

	include("connection.php");
	include("functions.php");
	$user_data = check_login($con);

?>
<!DOCTYPE html>
<html>
<head>
	<title>MPSLSW
	</title>
	<link rel="stylesheet" href="sites\css\font-awesome.min.css"> 
	<link rel="stylesheet" type="text/css" href="bootstrap.css">
<link rel="stylesheet" type="text/css" href="bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="bootstrap.rtl.css">
<link rel="stylesheet" type="text/css" href="bootstrap.rtl.min.css">
<link rel="stylesheet" type="text/css" href="bootstrap-grid.css">
<link rel="stylesheet" type="text/css" href="bootstrap-grid.min.css">
<link rel="stylesheet" type="text/css" href="bootstrap-grid.rtl.css">
<link rel="stylesheet" type="text/css" href="bootstrap-grid.rtl.min.css">
<link rel="stylesheet" type="text/css" href="bootstrap-reboot.css">
<link rel="stylesheet" type="text/css" href="bootstrap-reboot.min.css">
<link rel="stylesheet" type="text/css" href="bootstrap-reboot.rtl.css">
<link rel="stylesheet" type="text/css" href="bootstrap-reboot.rtl.min.css">
<link rel="stylesheet" type="text/css" href="bootstrap-utilities.css">
<link rel="stylesheet" type="text/css" href="bootstrap-utilities.min.css">
<link rel="stylesheet" type="text/css" href="bootstrap-utilities.rtl.css">
<link rel="stylesheet" type="text/css" href="bootstrap-utilities.rtl.min.css">

	 
</head>
<body>
	<style type="text/css">

#text{

height: 17px;
padding: 4px;
width: 25%;
border-radius: 3px;
border-color: none;
}



#box{
margin-left: 1060px;
align-content: flex-end;
margin-top: -170px;
}
.nav_links {
margin-top: 60px;
margin-left: 550px;
list-style: none;
}
.nav_links li {
display: inline-block;
}

.nav_links li a {
transition: all 0.3s ease 0s;
}


.nav_links input{
width: 200px;
color: white;
transition: all 0.3s ease 0s;
border-radius: 7px;

}
.descrip {
color: #228b22;
}
</style>
<header style="margin-left: -25px;">

<ul style="list-style: none; margin-left: -10px;">

    <li style="margin-top: -12px;"><a href="Home.php"><img src="logo_MoPWLSW-2.png"></a></li>
	<li><div style="margin-top: -120px; margin-left: 160px;">
		<h3> Ministry of<br>Public Service, Labour<br>Social Welfare.<br>Department of Social Welfare</h3>
	</div></li>
	

	<div id="box">
		

			<br><a href="Home.php"><input id="button" type="submit" class="btn btn-success" value="Log-Out"></a>
	</div>
	<script>
function myFunction() {
  alert("Log in to gain access.");
}
function myLogin(){
	alert("Welcome '<?php echo $user_data['user_name']; ?>'")
}
</script>
	<div class="nav_links">
		<nav>
		<lu>
			<li><a href="#"><input type="button" class="btn btn-success" name="" value="Beneficiary Registration" style="height: 40px; cursor:pointer;"></a></li>
			<li><a href="test.php"><input type="button" class="btn btn-success" name="" value="National Database" style="height: 40px; cursor:pointer;"></a></li>
			<li><a href="Contact.html"><input type="button" class="btn btn-success" name="" value="Contact Us" style="height: 40px; cursor:pointer; "></a></li>
			
		</lu>
		
	</div>
	</nav><br>
	<div><hr style="width: 75%; color: black; margin-left: 160px;"></div>
</ul>
	</header>
	<br><br><h2 style="color: green; text-align:center">Beneficiary Registration</h2>
	<h3 style="color: green; text-align:center">Welcome <?php echo $user_data['user_name']; ?></h3>
	<form method="POST" action="post.php"  class="reg">
	<div class="form-row">
	  
<div class="form-check form-check-inline col-md-5">
&nbsp;&nbsp;&nbsp;<label class="form-check-label" for="name">Name:</label>
<input type="text"  class="form-control" id="name" name="name" required>
</div>
<div class="form-check form-check-inline col-md-5">
&nbsp;&nbsp;&nbsp;<label class="form-check-label text-left" for="surname">Surname:</label>
<input type="text"  class="form-control" id="surname" name="surname" required>
</div><br><br>

<div class="form-check form-check-inline col-md-4">
&nbsp;&nbsp;&nbsp;<label class="form-check-label" for="nId">ID:</label>
<input type="text"  class="form-control" id="nId" name="nId" required>
</div>
<div class="form-check form-check-inline col-md-3">
&nbsp;&nbsp;&nbsp;<label class="form-check-label" for="phoneNumber">Phone Number:</label>
<input type="number"  class="form-control" id="phoneNumber" name="phoneNumber" required>
</div>
<div class="form-check form-check-inline col-md-3">
&nbsp;&nbsp;&nbsp;<label class="form-check-label" for="dob">Date of Birth:</label>
<input type="date"  class="form-control" id="dob" name="dob" required>
</div><br><br>
<div class="form-check form-check-inline col-md-10">
&nbsp;&nbsp;&nbsp;<label class="form-check-label" for="address">Address:</label>
<input type="text"  class="form-control" id="address" name="address" required>
</div><br><br>
<div class="form-check form-check-inline col-md-4">
&nbsp;&nbsp;&nbsp;<label class="form-check-label text-left" for="category">Category:</label>
<select name="category" id="category" class="form-control">
			<option value="Elderly">Elderly</option>
					<option value="Disabled">Disabled</option>
					<option value="SFT">SFT</option>
					<option value="Albinism">Albinism</option>
					<option value="Blind">Blind</option>
					<option value="Child-Headed">Child Headed</option>
					<option value="Chronic-Illiness">Chronic Illness</option>
				</select></div>
<div class="form-check form-check-inline col-md-1">
&nbsp;&nbsp;&nbsp;<label class="form-check-label text-left" for="gender">Gender:</label>
<input type="text" class="form-control" id="gender" name="gender"   required></div><br><br>



    
  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<button type="submit" name="save" class="btn btn-success">Save</button><br><br><br><br>

	</form> 

</body>
</html>
		