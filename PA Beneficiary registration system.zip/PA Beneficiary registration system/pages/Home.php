
<!DOCTYPE html>
<html lang="en">

<head>
 <title>
MPSLSW</title>

<link rel="stylesheet" type="text/css" href="bootstrap.css">
<link rel="stylesheet" type="text/css" href="bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="bootstrap.rtl.css">
<link rel="stylesheet" type="text/css" href="bootstrap.rtl.min.css">
<link rel="stylesheet" type="text/css" href="bootstrap-grid.css">
<link rel="stylesheet" type="text/css" href="bootstrap-grid.min.css">
<link rel="stylesheet" type="text/css" href="bootstrap-grid.rtl.css">
<link rel="stylesheet" type="text/css" href="bootstrap-grid.rtl.min.css">
<link rel="stylesheet" type="text/css" href="bootstrap-reboot.css">
<link rel="stylesheet" type="text/css" href="bootstrap-reboot.min.css">
<link rel="stylesheet" type="text/css" href="bootstrap-reboot.rtl.css">
<link rel="stylesheet" type="text/css" href="bootstrap-reboot.rtl.min.css">
<link rel="stylesheet" type="text/css" href="bootstrap-utilities.css">
<link rel="stylesheet" type="text/css" href="bootstrap-utilities.min.css">
<link rel="stylesheet" type="text/css" href="bootstrap-utilities.rtl.css">
<link rel="stylesheet" type="text/css" href="bootstrap-utilities.rtl.min.css">
	<link rel="stylesheet" href="sites\css\font-awesome.min.css"> 
<link rel="stylesheet" href="sites\css\font-awesome.min.css">
	<script>
function myFunction() {
  alert("Log in to gain access.");
}
function myLogin(){
	alert("Welcome '<?php echo $user_data['user_name']; ?>'")
}
</script>
</head>
<body>

<style type="text/css">
	
	#text{

		height: 17px;
		padding: 4px;
		width: 25%;
		border-radius: 3px;
		border-color: none;
	}



#box{
	margin-left: 720px;
    align-content: flex-end;
    margin-top: -170px;
  }
.nav_links {
	margin-top: 85px;
	margin-left: 550px;
    list-style: none;
}
.nav_links li {
    display: inline-block;
}

.nav_links li a {
    transition: all 0.3s ease 0s;
}


.nav_links input{
	width: 200px;
	color: white;
	transition: all 0.3s ease 0s;
	border-radius: 7px;
	
}
.descrip {
	color: #228b22;
}
text{
	border: 2px;
	border-radius: 1.5px;
}
	</style>
	<header style="margin-left: -25px;">

<ul style="list-style: none; margin-left: -10px;">

    <li style="margin-top: -10px;"><a href="Home.php"><img src="logo_MoPWLSW-2.png"></a></li>
	<li><div style="margin-top: -120px; margin-left: 160px;">
		<h4> Ministry of<br>Public Service, Labour<br>Social Welfare.<br>Department of Social Welfare</h4>
	</div></li>
	

	<div id="box">
		
	<form method="post">
			<input id="text" type="text" name="user_name" placeholder="Username">&nbsp;&nbsp;
			<input id="text" type="password" name="password" placeholder="Password">&nbsp;

			<input id="button"class="btn btn-success" type="submit" value="Login">
		</form>
	</div>
	<div class="nav_links">
		<nav>
		<lu>
			<li><a href="login1.php"><input type="button" class="btn btn-success" name="" value="Beneficiary Registration" onclick="myFunction()" style="height: 40px; cursor:pointer;"></a></li>
			<li><a href="login2.php"><input type="button" class="btn btn-success" name="" value="National Database" onclick="myFunction()" style="height: 40px; cursor:pointer;"></a></li>
			<li><a href="Contact.html"><input type="button" class="btn btn-success" name="" value="Contact Us" style="height: 40px; cursor:pointer;"></a></li>
			
		</lu>
		
	</div>
	</nav><br>
	<div><hr style="width: 75%; color: black; margin-left: 160px;"></div>
</ul>
	</header><br>
<form>
	<div class="descrip" style="margin-left: 160px;"><h4 style="font-size: 30px;">The Department of Social Development aims reduce poverty and enhance <br>self-reliance through the provision
	 of social protection services to vulnerable <br>and disadvantaged groups in Zimbabwe.</h4></div>
	<p><div style="margin-left: 160px;">The Ministry enforces and promotes awareness of employment standards, such as minimum wage, hours of work, public holidays and<br>
	other standards. Explore this website to learn more about employee rights and employer obligations in Zimbabwe.</p>
<h4 style="color: #228b22; font-size: 20px;">What we do</h4>
		<ul>
		&nbsp;<li style="text-decoration: none; list-style:none; margin-left: -7px"><h3>Family Social Protection <br>Services</h3></li><hr style="width: 22%; margin-left: -10px">
			&nbsp;<li>Investigating and assessing cases of <br>public assistance.</li>
			&nbsp;<li>Paying fees and grants to institutions.</li>
			&nbsp;<li>Rehabilitating delinquents.</li>
			&nbsp;<li>Promoting rights of vulnerable groups by <br>conducting awareness campaigns.</li>
		</ul>

	<div style="margin-left: 340px; margin-top: -382px;">
		<ul>
		&nbsp;<li style="text-decoration: none; list-style:none;"><h3>Rehabilitation and PVO <br>Administration</h3></li><hr style="width: 34%; margin-left: -18px">
		&nbsp;<li>Registration of private voluntary organizations</li>
			&nbsp;<li>Registration and counseling of refugees</li>
			&nbsp;<li>Paying maintenance allowances to refugees</li>
			&nbsp;<li>Repatriating foreign national whenever conditions<br> are conducive</li>
		</ul>
	</div>
	<div  style="margin-left: 750px; margin-top: -325px;">
		<ul>
		&nbsp;<li style="text-decoration: none; list-style:none;"><h3>Policy and  Social Projects</h3></li><hr style="width: 70%; margin-left: -15px;">
			&nbsp;<li>Undertakes poverty assessments to establish <br>depth and distribution of national poverty</li>
			&nbsp;<li>Coordinates the design and formulation of social <br>policy on a continuous basis</li>
			&nbsp;<li>Recommends adoption of policies in the social <br>services department</li>
			&nbsp;<li>Monitors overall performance of special programmes <br>housed in the department</li>
			&nbsp;<li>Sets and reviews standards and guidelines for the <br>delivery of social protection</li>
			&nbsp;<li>Administers drought relief assistance</li>
		</ul>
	</div>
</div><br><br>

	</form>
	<div class="footer"><BR>
   <div class="socials">
	  &nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;  Contacts<BR>
     <ul>
      <li><a href="#"<i class="fa fa-facebook icon-4x"></a></li>
       <li><a href="#"<i class="fa fa-instagram"></a></li>
      <li><a href="#"<i class="fa fa-twitter"></a></li>
      <li><a href="#"<i class="fa fa-vimeo"></a></li>
      <li><a href="#"<i class="fa fa-whatsapp"></a></li>
    </ul>
    </div>
	
		<ul> 
			<li><a href="#">Privacy Policy</a> | <a href="#"> Terms & conditions</a></li>
			<li>Copyright <i class="fa fa-copyright"></i> Trevormg.</li>
			<li>Developed by Trevor</li>
		</ul>
	</div>


</body>
</html>