<?php
include 'connection.php';
header('Content-type: application/vnd-ms-excel');
$filename = "Beneficiary-data.xls";
header("Content-Disposition: attachment; filemane=\"$filename\"");

?>
	<table class="table table-bordered">
  <thead>
    <tr>
      <th>#</th>
      <th>Name</th>
      <th>Surname</th>
      <th>Id Number</th>
	  <th>Phone Number</th>
	  <th>Date of Birth</th>
	  <th>Gender</th>
	  <th>Address</th>
	  <th>Category</th>
    </tr>
  </thead>
  <tbody>
    <?php
    $id=1;
    $sql ="SELECT * FROM benefiary";
    $disp_result = mysqli_query($con,$sql);
      while ($row=mysqli_fetch_assoc($disp_result)) {   
?>
<tr>
     <td><?php echo $id;?></td>
     <td><?php echo $row["name"];?></td>
     <td><?php echo $row['surname'];?></td>
     <td><?php echo $row['nId'];?></td>
     <td><?php echo $row['phoneNumber'];?></td>
     <td><?php echo $row['dob'];?></td>
     <td><?php echo $row['gender'];?></td>
     <td><?php echo $row['address'];?></td>
     <td><?php echo $row['category'];?></td>
     </tr>
     <?php
     $id++;
    }
     ?>
  
  </tbody>
</table>
