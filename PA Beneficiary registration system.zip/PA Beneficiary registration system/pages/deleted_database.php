<?php
session_start();

include("connection.php");
include("functions.php");
$user_data = check_login($con);

if (isset($_POST['search'])) {
    $valuetosearch = $_POST['valuetosearch'];
    $query = "SELECT * FROM ben_deleted WHERE CONCAT (`id`, `nId`, `phoneNumber`, `name`, `surname`, `dob`, `address`, `category`, `gender`) LIKE '%".$valuetosearch."%'";
    $search_result = filterTable($query);
}
else {
    $query = "SELECT * FROM ben_deleted";
    $search_result = filterTable($query);

}
function filterTable($query){
    $connect = mysqli_connect("localhost", 'root', '', 'PublicAssistance');
    $filter_Result = mysqli_query($connect, $query);
    return $filter_Result;
}?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Deleted Beneficiaries</title>
	<link rel="stylesheet"  href="fontawesome-free-6.0.0-beta3-web\fontawesome-free-6.0.0-beta3-web\css\all.css">
<link rel="stylesheet" type="text/css" href="bootstrap.css">
<link rel="stylesheet" type="text/css" href="bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="bootstrap.rtl.css">
<link rel="stylesheet" type="text/css" href="bootstrap.rtl.min.css">
<link rel="stylesheet" type="text/css" href="bootstrap-grid.css">
<link rel="stylesheet" type="text/css" href="bootstrap-grid.min.css">
<link rel="stylesheet" type="text/css" href="bootstrap-grid.rtl.css">
<link rel="stylesheet" type="text/css" href="bootstrap-grid.rtl.min.css">
<link rel="stylesheet" type="text/css" href="bootstrap-reboot.css">
<link rel="stylesheet" type="text/css" href="bootstrap-reboot.min.css">
<link rel="stylesheet" type="text/css" href="bootstrap-reboot.rtl.css">
<link rel="stylesheet" type="text/css" href="bootstrap-reboot.rtl.min.css">
<link rel="stylesheet" type="text/css" href="bootstrap-utilities.css">
<link rel="stylesheet" type="text/css" href="bootstrap-utilities.min.css">
<link rel="stylesheet" type="text/css" href="bootstrap-utilities.rtl.css">
<link rel="stylesheet" type="text/css" href="bootstrap-utilities.rtl.min.css">

 
</head>
<body scope="col">

<style type="text/css">

/* #button{

padding: 10px;
margin-right: 5px;
width: 100px;
color: white;
border-radius: 7px;
transition: all 0.3s ease 0s;
cursor: pointer;
} */
#box{
margin-left: 1060px;
align-content: flex-end;
margin-top: -170px;
}
.nav_links {
margin-top: 60px;
margin-left: 550px;
list-style: none;
}
.nav_links li {
display: inline-block;
}

.nav_links li a {
transition: all 0.3s ease 0s;
}

.nav_links li a:hover {
color: #0088a9;
}

.nav_links input{
width: 200px;
color: white;
transition: all 0.3s ease 0s;
border-radius: 7px;

}

</style>
<header style="margin-left: -25px;">

<ul style="list-style: none; margin-left: -10px;">

    <li style="margin-top: -10px;"><a href="Home.php"><img src="logo_MoPWLSW-2.png"></a></li>
	<li><div style="margin-top: -120px; margin-left: 160px;">
		<h3> Ministry of<br>Public Service, Labour<br>Social Welfare.<br>Department of Social Welfare</h3>
	</div></li>
	

	<div id="box">
		
		<form>
<br>
			<a href="Home.php"><input id="button" type="button" class="btn btn-success" value="Log-Out"></a>
		</form>
	</div>
	<script>
function myFunction() {
  alert("Log in to gain access.");
}
function myLogin(){
	alert("Welcome '<?php echo $user_data['user_name']; ?>'")
}
</script>
	<div class="nav_links">
		<nav>
		<lu>
			<li><a href="index.php"><input type="button" class="btn btn-success" name="" value="Beneficiary Registration"></a></li>
			<li><a href="test.php"><input type="button" class="btn btn-success" name="" value="National Database" ></a></li>
			<li><a href="Contact.html"><input type="button" class="btn btn-success" name="" value="Contact Us"></a></li>
			
		</lu>
		
	</div>
	</nav><br>
	<div><hr style="width: 75%; color: black; margin-left: 160px;"></div>
</ul>
	</header><br>
	<form method="POST">
        <input type="submit" class="btn btn-primary" name="search" value="Filter">&nbsp;<input type="text" style="padding: 4px;border-radius: 3px;border-color: none;" name="valuetosearch"><div class="col-md-12 head"><br>
        <div class="float-right">
            <a href="export_deleted.php" target="_blank"><button type="button" class="btn btn-success" scope="col">Export <i class="fas fa-file-download"></i></button></a>
        </div>
    </div><br><h3 scope="col" style="text-align:center">PA Deleted Beneficiary</h3><br><br>

    <table class="table table-striped table-hover">
  <thead>
    <tr>
      <th scope="col">#</th>
      <th scope="col"><h4>Name</h4></th>
      <th scope="col"><h4>Surname</h4></th>
      <th scope="col"><h4>Id Number</h4></th>
	  <th scope="col"><h4>Phone Number</h4></th>
	  <th scope="col"><h4>Date of Birth</h4></th>
	  <th scope="col"><h4>Gender</h4></th>
	  <th scope="col"><h4>Address</h4></th>
	  <th scope="col"><h4>Category</h4></th>
	  <th scope="col"><h4>User</h4></th>
	  <th scope="col"><h4>Reason</h4></th>

    </tr>
  </thead>
  <tbody class="text-center">

    <?php
    $sql ="SELECT * FROM ben_deleted ORDER BY `ben_deleted`.`id` ASC";
    $disp_result = mysqli_query($con,$sql);
    if ($disp_result) {
      while ($row=mysqli_fetch_assoc($disp_result)) {
        $id =$row['id'];
        $name =$row['name'];
        $surname =$row['surname'];
        $nId =$row['nId'];
        $phoneNumber =$row['phoneNumber'];
        $dob =$row['dob'];
        $gender =$row['gender'];
        $address =$row['address'];
        $category =$row['category'];
		$user =$row['user'];
		$reason =$row['reason'];
        
        echo '<tr>
        <th scope="row">'.$id.'</th>
        <td>'.$name.'</td>
        <td>'.$surname.'</td>
        <td>'.$nId.'</td>
        <td>'.$phoneNumber.'</td>
        <td>'.$dob.'</td>
        <td>'.$gender.'</td>
        <td>'.$address.'</td>
        <td>'.$category.'</td>
		<td>'.$user.'</td>
		<td>'.$reason.'</td>

        </tr>';
        

      }
      
    }
?>
  
  </tbody> 
  
</table><br><br><br>

</body>
</html>