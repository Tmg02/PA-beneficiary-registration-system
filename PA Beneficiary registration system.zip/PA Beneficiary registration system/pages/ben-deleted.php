<?php
include("connection.php");
include("functions.php");
$user_data = check_login($con);
$host = "localhost";
$user = "root";
$pass = "";
$db = "PublicAssistance";

$con = mysqli_connect($host,$user,$pass,$db);
if (!$con){
	echo "There is a problem connecting the database"; 
}
$name = $_POST['name'];
$surname =$_POST['surname'];
$dob = $_POST['dob'];
$phoneNumber = $_POST['phoneNumber'];
$category = $_POST['category'];
$address = $_POST['address'];
$gender = $_POST['gender'];
$nId = $_POST['nId'];
$reason=$_POST['reason'];

$qry = ("INSERT INTO `ben_deleted`(`nId`, `phoneNumber`, `name`, `surname`, `dob`, `address`, `category`, `gender`, 'reason', 'user') VALUES ('$nId','$phoneNumber','$name','$surname','$dob','$address','$category','$gender', '$reason', '$user_data' )");
$insert = mysqli_query($con, $qry);
if (!$insert){
	echo "There were problems while saving data";
}
else{
	
}
?>