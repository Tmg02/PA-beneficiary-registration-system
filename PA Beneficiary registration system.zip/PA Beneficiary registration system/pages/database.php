<?php 
session_start();

	include("connection.php");
	include("functions.php");

?>
<!DOCTYPE html>
<html>
<head>
	<title>My website
	</title>
	<link rel="stylesheet" href="sites\css\font-awesome.min.css"> 
	<style type="text/css">
		table{
			width: 100%;
			color: #228b22;
			font-family: monospace;
			font-size: 25px;
			text-align: left;
			border-collapse: separate;
		}
		th{
			background-color: #228b22;
			color: white;
			border-color: black;
		}
		tr:nth-child(even){
			background-color: #f2f2f2;
		}
	</style>
</head>
<body>

	<a href="home.php">Logout</a>
	
        <input type="text" name="id">&nbsp;<input type="submit" >

    
	<?php
		$mysqli = new mysqli('localhost', 'root', '', 'PublicAssistance') or die(mysqli_error($mysqli));
		$result = $mysqli->query("SELECT * FROM `benefiary`  WHERE id = $id") or die($mysqli->error);
		//pre_r($result);?>
		<h3 style="color: green; text-align:center">PA Beneficiary</h3>
		
	<table>
		<tr>
			<th><h3>#</h3></th>
			<th><h3>Name</h3></th>
			<th><h3>Surname</h3></th>
			<th><h3>Id Number</h3></th>
			<th><h3>Phone Number</h3></th>
			<th><h3>Date of Birth</h3></th>
			<th><h3>Gender</h3></th>
			<th><h3>Address</h3></th>
			<th><h3>Category</h3></th>
			<th><h3>Action</h3></th>	
		</tr>
		<?php while ($row = $result->fetch_assoc()):?>
			<tr>
				<td><?php echo $row['id'];?></td>
				<td><?php echo $row['name'];?></td>
				<td><?php echo $row['surname'];?></td>
				<td><?php echo $row['nId'];?></td>
				<td><?php echo $row['phoneNumber'];?></td>
				<td><?php echo $row['dob'];?></td>
				<td><?php echo $row['gender'];?></td>
				<td><?php echo $row['address'];?></td>
				<td><?php echo $row['category'];?></td>
				<td><a href="update.php?id=<?php echo $row["id"]; ?>"><button>Update</button></a><a href="process.php?id=<?php echo $row["id"] ?>"><button>Delete</button></a></td>

			</tr>
		<?php endwhile; ?>
		
	</table>
</body>
</html>
		